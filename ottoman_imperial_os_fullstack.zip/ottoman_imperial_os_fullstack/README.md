# Ottoman Imperial OS — Full-Stack Implementation

A runnable version of the existing **Ottoman Imperial OS — Sovereign Command Center** frontend with a Python/Flask backend and SQLite persistence.

> This is a fictional governance/strategy simulation interface. The Ottoman framing is used as the product theme; it is not an operational government system.

## Stack

- **Frontend:** standalone HTML/CSS/JavaScript SPA (the supplied UI)
- **Backend:** Python 3 standard library HTTP server
- **Database:** SQLite
- **API:** JSON REST endpoints under `/api`
- **Fallback:** browser `localStorage` if the backend is unavailable
- **Tests:** Python unittest

## Project layout

```text
ottoman_imperial_os_fullstack/
├── backend/
│   ├── app.py
│   └── requirements.txt
├── frontend/
│   └── index.html
├── tests/
│   └── test_api.py
├── data/                 # created automatically; SQLite DB lives here
├── .env.example
├── .gitignore
├── README.md
├── run_windows.bat
└── run_linux_mac.sh
```

## Requirements

Install **Python 3.10+** (3.11/3.12 recommended). No third-party Python packages are required.

## Test locally — Windows

Open Command Prompt or PowerShell in the project directory:

```powershell
python -m venv .venv
.venv\Scripts\activate
python backend\app.py
```

Then open:

**http://127.0.0.1:5000**

You can also double-click `run_windows.bat`; it creates the virtual environment, installs dependencies, and starts the server.

## Test locally — Linux/macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python backend/app.py
```

Then open:

**http://127.0.0.1:5000**

Or run:

```bash
./run_linux_mac.sh
```

## Verify the backend

With the server running:

```bash
curl http://127.0.0.1:5000/api/health
```

Expected shape:

```json
{"database":".../data/ottoman_os.sqlite3","ok":true,"service":"ottoman-imperial-os"}
```

Check the saved state:

```bash
curl http://127.0.0.1:5000/api/state
```

## Run automated tests

From the project root:

```bash
python -m unittest discover -s tests -v
```

The tests cover:

1. backend health endpoint;
2. state save/read round trip;
3. state reset endpoint.

## How frontend ↔ backend works

1. The browser loads the command center.
2. The app immediately calls `GET /api/state`.
3. If a database state exists, it replaces the local copy and renders it.
4. Every existing mutation that calls the app's `saveData()` now:
   - updates localStorage immediately;
   - sends the complete state to `PUT /api/state`;
   - reports backend sync status in the left footer.
5. If the backend cannot be reached, the app continues using localStorage.
6. The **Settings → Check Backend** button verifies connectivity.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Backend health check |
| GET | `/api/state` | Load complete OS state |
| PUT | `/api/state` | Save complete OS state |
| POST | `/api/state/reset` | Replace state with supplied demo/reset state |
| GET | `/api/export` | Read current server state as JSON |
| GET | `/` | Serve the frontend |

## Database

SQLite is automatically created at:

```text
data/ottoman_os.sqlite3
```

The database is intentionally excluded from Git via `.gitignore`.

To reset the development database completely, stop the server and delete that file. On the next run, the frontend's demo state will be uploaded to the backend.

## Production note

This package is **development/test ready**, not production-hardened. Before public deployment, add authentication/authorization, CSRF protection where applicable, server-side validation/schema enforcement, audit logging, backups, rate limiting, HTTPS, secrets management, and a proper multi-user data model.
