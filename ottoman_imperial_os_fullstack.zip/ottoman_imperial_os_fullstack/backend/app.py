import json
import os
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / 'frontend'
DB_PATH = Path(os.getenv('DATABASE_PATH', ROOT / 'data' / 'ottoman_os.sqlite3'))
HOST = os.getenv('HOST', '127.0.0.1')
PORT = int(os.getenv('PORT', '5000'))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def db_connect():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with db_connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS os_state (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL, updated_at TEXT NOT NULL)')
        c.commit()


def read_state():
    with db_connect() as c:
        row = c.execute('SELECT payload FROM os_state WHERE id=1').fetchone()
    return json.loads(row['payload']) if row else None


def write_state(state):
    payload = json.dumps(state, ensure_ascii=False)
    now = datetime.now(timezone.utc).isoformat()
    with db_connect() as c:
        c.execute('''INSERT INTO os_state(id,payload,updated_at) VALUES(1,?,?)
                     ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at''', (payload, now))
        c.commit()


def send_json(handler, status, payload):
    raw = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(raw)))
    handler.send_header('Access-Control-Allow-Origin', '*')
    handler.send_header('Access-Control-Allow-Headers', 'Content-Type')
    handler.send_header('Access-Control-Allow-Methods', 'GET,PUT,POST,OPTIONS')
    handler.end_headers()
    handler.wfile.write(raw)


class Handler(BaseHTTPRequestHandler):
    server_version = 'OttomanImperialOS/1.0'

    def log_message(self, fmt, *args):
        print('%s - %s' % (self.address_string(), fmt % args))

    def do_OPTIONS(self):
        send_json(self, 204, {})

    def _json_body(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
            return json.loads(self.rfile.read(length) or b'{}')
        except (ValueError, json.JSONDecodeError):
            return None

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/health':
            return send_json(self, 200, {'ok': True, 'service': 'ottoman-imperial-os', 'database': str(DB_PATH)})
        if path == '/api/state':
            state = read_state()
            return send_json(self, 200, {'exists': state is not None, 'state': state})
        if path == '/api/export':
            state = read_state()
            if state is None:
                return send_json(self, 404, {'error': 'No state has been saved yet'})
            return send_json(self, 200, state)
        return self.serve_frontend(path)

    def do_PUT(self):
        path = urlparse(self.path).path
        if path != '/api/state':
            return send_json(self, 404, {'error': 'Not found'})
        body = self._json_body()
        if not isinstance(body, dict):
            return send_json(self, 400, {'error': 'JSON object required'})
        write_state(body)
        return send_json(self, 200, {'ok': True, 'state': body})

    def do_POST(self):
        path = urlparse(self.path).path
        if path != '/api/state/reset':
            return send_json(self, 404, {'error': 'Not found'})
        body = self._json_body()
        state = body.get('state') if isinstance(body, dict) else None
        if not isinstance(state, dict):
            return send_json(self, 400, {'error': 'state JSON object required'})
        write_state(state)
        return send_json(self, 200, {'ok': True, 'state': state})

    def serve_frontend(self, path):
        relative = path.lstrip('/') or 'index.html'
        target = (FRONTEND / relative).resolve()
        try:
            target.relative_to(FRONTEND.resolve())
        except ValueError:
            return send_json(self, 403, {'error': 'Forbidden'})
        if not target.is_file():
            target = FRONTEND / 'index.html'
        data = target.read_bytes()
        mime = 'text/html; charset=utf-8'
        if target.suffix == '.css': mime = 'text/css; charset=utf-8'
        elif target.suffix == '.js': mime = 'application/javascript; charset=utf-8'
        elif target.suffix == '.json': mime = 'application/json; charset=utf-8'
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main():
    init_db()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f'Ottoman Imperial OS running at http://{HOST}:{PORT}')
    print(f'SQLite database: {DB_PATH}')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nServer stopped.')
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
