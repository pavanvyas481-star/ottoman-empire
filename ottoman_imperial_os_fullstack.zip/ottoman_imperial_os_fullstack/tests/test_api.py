import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))
import app as server


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        server.DB_PATH = Path(cls.tmp.name) / 'test.sqlite3'
        server.init_db()
        cls.httpd = server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.httpd.server_address[1]}'

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.tmp.cleanup()

    def request(self, method, path, payload=None):
        data = None if payload is None else json.dumps(payload).encode()
        req = Request(self.base + path, data=data, method=method, headers={'Content-Type': 'application/json'})
        with urlopen(req, timeout=3) as r:
            return r.status, json.loads(r.read())

    def test_health(self):
        status, body = self.request('GET', '/api/health')
        self.assertEqual(status, 200)
        self.assertTrue(body['ok'])

    def test_state_roundtrip(self):
        sample = {'projects': [{'id': 'P-TEST', 'name': 'Test Project'}], 'decisions': []}
        status, _ = self.request('PUT', '/api/state', sample)
        self.assertEqual(status, 200)
        status, body = self.request('GET', '/api/state')
        self.assertEqual(status, 200)
        self.assertEqual(body['state'], sample)

    def test_reset(self):
        sample = {'reset': True}
        status, _ = self.request('POST', '/api/state/reset', {'state': sample})
        self.assertEqual(status, 200)
        _, body = self.request('GET', '/api/state')
        self.assertEqual(body['state'], sample)


if __name__ == '__main__':
    unittest.main()
